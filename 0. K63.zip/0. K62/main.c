#include <stdio.h>
#include <stdlib.h>
#include <stdio_ext.h> // __fpurge(stdin);
#include <string.h>
#include "dslkdon.h"

typedef struct
{
    int stt;
    char tenmon[255];
    int soluong;
    double giaitien;
    int uaChuong;
} monAn;

void fileOpenRead(FILE **f, char filename[]);

int somon;
void inputDataFromTxt(monAn MONAN[], char filename[])
{
    FILE *fin;
    fileOpenRead(&fin, filename);

    fscanf(fin, "%d", &somon);
    if (somon < 0 || somon > 8)
    {
        printf("\nLoi! So mon phai > 0 va <= 8, vui long sua lai file du lieu!\n");
        exit(0);
    }
    int i = 0;
    while (1)
    {
        fscanf(fin, "%d %s %d %lf", &MONAN[i].stt, MONAN[i].tenmon, &MONAN[i].soluong, &MONAN[i].giaitien);
        if (feof(fin))
            break;

        if (MONAN[i].soluong < 0 || MONAN[i].giaitien < 0)
        {
            printf("\nFile dau vao loi! Vui long sua lai!\n");
            exit(0);
        }
        i++;
    }
}

void displayThucDon(monAn MON[])
{
    printf("Tong so mon an hom nay: %d\n", somon);
    printf("\n%-5s %-20s %-10s %s\n", "STT", "Ten Mon An", "SL Ton", "Tien");
    for (int i = 0; i < somon; i++)
    {
        printf("%-5d %-20s %-10d %.2lf\n", MON[i].stt, MON[i].tenmon, MON[i].soluong, MON[i].giaitien);
    }
}

int ID_dathang = 0;

void nhanOrder(node **head, monAn MON[])
{
    ID_dathang++;
    elType data;
    data.stt = ID_dathang;
    for (int i = 0; i < somon; i++)
    {
    BACK:
        printf("So luong mon %s la: ", MON[i].tenmon);
        scanf("%d", &data.order[i]);
        if (data.order[i] < 0)
        {
            printf("\nNhap lai so luong >= 0\n");
            goto BACK;
        }
    }

    for (int i = 0; i < somon; i++)
    {
        if (data.order[i] > MON[i].soluong)
        {
            ID_dathang--;
            printf("\nXin loi nha hang khong du suat an dap ung yeu cau quy khach!\n");
            printf("\nThuc don hom nay con!\n");
            displayThucDon(MON);
            return;
        }
    }
    
    for (int i = 0; i < somon; i++)
    {
        MON[i].uaChuong = MON[i].uaChuong + data.order[i];
        MON[i].soluong = MON[i].soluong - data.order[i];
    }

    data.total = 0;
    for (int i = 0; i < somon; i++)
    {
        data.total += data.order[i] * MON[i].giaitien;
    }
    insertLast(head, data);

    printf("\nDon hang so: %d\n", ID_dathang);
        printf("%-20s %-20s %s\n", "Mon da chon", "So luong", "Thanh tien");
        for (int i = 0; i < somon; i++)
        {
            if (data.order[i] != 0)
            {
                printf("%-20s %-20d %.2f\n", MON[i].tenmon, data.order[i], data.order[i] * MON[i].giaitien);
            }
        }
        printf("Tong hoa don thanh toan: %ld\n", data.total);
}

void display_Order(node *head, monAn MON[])
{
    for (node *p = head; p != NULL; p = p->next)
    {
        printf("\nDon hang so: %d\n", p->data.stt);
        printf("%-20s %-20s %s\n", "Mon da chon", "So luong", "Thanh tien");
        for (int i = 0; i < somon; i++)
        {
            if (p->data.order[i] != 0)
            {
                printf("%-20s %-20d %.2f\n", MON[i].tenmon, p->data.order[i], p->data.order[i] * MON[i].giaitien);
            }
        }
        printf("Tong hoa don thanh toan: %ld\n", p->data.total);
    }
}

void monAnUaChuong(monAn MON[])
{
    int max = 0;
    for (int i = 0; i < somon; i++)
    {
        if (MON[i].uaChuong > max)
            max = MON[i].uaChuong;
    }

    printf("\n\nMon an duoc ua chuong nhat la!\n");
    for (int i = 0; i < somon; i++)
    {
        if (MON[i].uaChuong == max)
        {
            printf("%s voi so luong goi %d\n", MON[i].tenmon, MON[i].uaChuong);
        }
    }
}

int main()
{
    node *head = NULL;
    monAn MON[8];
    char thucdontheongay[] = "thucdontheongay.txt";
    inputDataFromTxt(MON, thucdontheongay);

    for (int i = 0; i < somon; i++)
        MON[i].uaChuong = 0;

    int luachon;
    do
    {
        printf("\n----------------------------\n"
               "QUAN LI NHA HANG\n"
               "1. Danh sach an hom nay!\n"
               "2. Nhan Order\n"
               "3. Thong tin tat ca Order\n"
               "4. Mon an ua chuong nhat\n"
               "5. Thoat\n"
               "---> Chon: ");
        scanf("%d", &luachon);
        switch (luachon)
        {
        case 1:
            displayThucDon(MON);
            break;
        case 2:
            nhanOrder(&head, MON);
            break;
        case 3:
        {
            if (ID_dathang != 0)
                display_Order(head, MON);
            else
                printf("\nChua co don hang nao!\n");
        }
        break;
        case 4:
        {
            if (ID_dathang != 0)
                monAnUaChuong(MON);
            else
                printf("\nChua co don hang nao!\n");
        }
        break;
        case 5:
            break;
        default:
            printf("\nNhap lai gia tri!\n");
            break;
        }
    } while (luachon != 5);

    if (head != NULL)
        removeNode(&head);
    return 0;
}

void fileOpenRead(FILE **f, char filename[])
{
    if ((*f = fopen(filename, "r")) == NULL)
    {
        printf("Can't open file: %s\n", filename);
        exit(0);
    }
}