#ifndef LINK_LIST_DSLK1
#define LINK_LIST_DSLK1

typedef struct
{
	int stt;
	int order[8];
	long total;
} elType;

typedef struct node
{
	elType data;
	struct node *next;
} node;

void insertFirst(node **head, elType data);
void insertLast(node **head, elType data);
void removeHead(node **head);
void removeTail(node **head);

// Free linkList
void removeNode(node **head);

int lenNode(node *head);

void xoaBatKi(node **head, int vitri);
void chenBatKi(node **head, elType data, int vitri);
void daoNguocDS(node **head);

#endif
