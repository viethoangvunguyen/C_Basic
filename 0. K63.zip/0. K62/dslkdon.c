#include <stdio.h>
#include <stdlib.h>
#include "dslkdon.h"

node *makeNode(elType data)
{
  node *p = (node *)malloc(sizeof(node));
  if (p == NULL)
    return NULL;
  p->data = data;
  p->next = NULL;
  return p;
}

void insertFirst(node **head, elType data)
{
  node *p = makeNode(data);
  if (*head == NULL)
    *head = p;
  else
  {
    p->next = *head;
    *head = p;
  }
}

void insertLast(node **head, elType data)
{
  node *p = makeNode(data);
  if (*head == NULL)
    *head = p;
  else
  {
    node *q = *head;
    while (q->next != NULL)
      q = q->next;
    q->next = p;
  }
}

void removeHead(node **head)
{
  if (*head == NULL)
    return;
  node *p = *head;
  *head = (*head)->next;
  p->next = NULL;

  if (p == *head)
    *head = NULL;
  free(p);
}

void removeTail(node **head)
{
  if (*head == NULL)
    return;
  node *p = *head;
  node *back;
  while (p->next != NULL)
  {
    back = p;
    p = p->next;
  }
  if (back != NULL)
    back->next = NULL;

  if (p == *head)
    *head = NULL;

  free(p);
}

void removeNode(node **head)
{
  node *p = NULL;
  while (*head != NULL)
  {
    p = *head;
    *head = (*head)->next;
    free(p);
  }
}

int lenNode(node *head)
{
  if (head == NULL)
    return 0;
  else
    return 1 + lenNode(head->next);
}

void xoaBatKi(node **head, int vitri)
{
  int i = 1;
  node *prev;
  for (node *p = *head; p != NULL; p = p->next)
  {
    if (vitri == 1)
    {
      removeHead(head);
      break;
    }
    else if (vitri == lenNode(*head))
      removeTail(head);
    else if (vitri == i)
    {
      node *xoa = p;
      prev->next = p->next;
      free(xoa);
      break;
    }
    i++;
    prev = p;
  }
}

void chenBatKi(node **head, elType data, int vitri)
{
  int i = 1;
  node *prev;
  for (node *p = *head; p != NULL; p = p->next)
  {
    if (vitri == 1)
    {
      insertFirst(head, data);
      break;
    }
    if (vitri > lenNode(*head))
    {
      insertLast(head, data);
      break;
    }
    if (vitri == i)
    {
      node *new = makeNode(data);
      prev->next = new;
      new->next = p;
      break;
    }
    i++;
    prev = p;
  }
}

void daoNguocDS(node **head)
{
  node *p = NULL;
  node *newHead = NULL;

  while (*head != NULL)
  {
    p = *head;
    *head = (*head)->next;

    if (newHead == NULL)
    {
      p->next = NULL;
      newHead = p;
    }
    else
    {
      p->next = newHead;
      newHead = p;
    }
  }
  
  *head = newHead;
}
